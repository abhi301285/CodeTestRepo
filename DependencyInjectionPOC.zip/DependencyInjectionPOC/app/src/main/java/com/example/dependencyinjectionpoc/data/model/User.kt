package com.example.dependencyinjectionpoc.data.model

import android.text.format.DateFormat
import java.util.*

class User {

    var id: Long? = null
    var name: String? = null
    var address: String? = null
    var createdAt: String? = null
    var updatedAt: String? = null

    constructor() {}

    constructor(name: String, address: String) {
        this.name = name
        this.address = address
    }

    override fun toString(): String {
        val createdAtString = DateFormat.format("MM/dd/yyyy", Date(java.lang.Long.parseLong(createdAt))).toString()
        val updatedAtString = DateFormat.format("MM/dd/yyyy", Date(java.lang.Long.parseLong(updatedAt))).toString()
        return  "id= " + id +
                "\nname= " + name +
                "\naddress= " + address +
                "\ncreatedAt= " + createdAtString  +
                "\nupdatedAt= " + updatedAtString +"\n" +
                "\n" +
                "\n"
    }
}