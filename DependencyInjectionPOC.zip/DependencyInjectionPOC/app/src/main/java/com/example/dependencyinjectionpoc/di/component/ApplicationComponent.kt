package com.example.dependencyinjectionpoc.di.component

import android.app.Application
import android.content.Context
import com.example.dependencyinjectionpoc.DIApplication
import com.example.dependencyinjectionpoc.data.DataManager
import com.example.dependencyinjectionpoc.data.DbHelper
import com.example.dependencyinjectionpoc.data.SharedPrefsHelper
import com.example.dependencyinjectionpoc.di.ApplicationContext
import com.example.dependencyinjectionpoc.di.module.ApplicationModule
import dagger.Component
import javax.inject.Singleton


/**
 * Created by Abhijit on 22/03/19.
 */

@Singleton
@Component(modules = [ApplicationModule::class])
interface ApplicationComponent {

    @get:ApplicationContext
    val context: Context

    val application: Application

    val dataManager: DataManager

    val preferenceHelper: SharedPrefsHelper

    val dbHelper: DbHelper

    fun inject(demoApplication: DIApplication)

}