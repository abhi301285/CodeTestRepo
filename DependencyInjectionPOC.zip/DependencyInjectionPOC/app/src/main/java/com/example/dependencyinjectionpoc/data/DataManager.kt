package com.example.dependencyinjectionpoc.data

import android.content.Context
import android.content.res.Resources
import com.example.dependencyinjectionpoc.data.model.User
import com.example.dependencyinjectionpoc.di.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class DataManager @Inject
constructor(
    @param:ApplicationContext val mContext: Context,
    val mDbHelper: DbHelper,
    val mSharedPrefsHelper: SharedPrefsHelper
) {

    val accessToken: String?
        get() = mSharedPrefsHelper.get(SharedPrefsHelper.PREF_KEY_ACCESS_TOKEN, "")

    fun saveAccessToken(accessToken: String) {
        mSharedPrefsHelper.put(SharedPrefsHelper.PREF_KEY_ACCESS_TOKEN, accessToken)
    }

    @Throws(Exception::class)
    fun createUser(user: User): Long? {
        return mDbHelper.insertUser(user)
    }

    @Throws(Resources.NotFoundException::class, NullPointerException::class)
    fun getUser(userId: Long?): User {
        return mDbHelper.getUser(userId)
    }

    @Throws(Resources.NotFoundException::class, NullPointerException::class)
    fun getAllUser(): ArrayList<User> {
        return mDbHelper.getAllUser()
    }

    fun deleteAllUsers() {
        return mDbHelper.deleteAllUserData()
    }
}