package com.example.dependencyinjectionpoc.di.module

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import com.example.dependencyinjectionpoc.di.ApplicationContext
import com.example.dependencyinjectionpoc.di.DatabaseInfo
import dagger.Module
import dagger.Provides


/**
 * Created by Abhijit on 22/03/19.
 */

@Module
class ApplicationModule(private val mApplication: Application) {

    @Provides
    @ApplicationContext
    fun provideContext(): Context {
        return mApplication
    }

    @Provides
    fun provideApplication(): Application {
        return mApplication
    }

    @Provides
    @DatabaseInfo
    fun provideDatabaseName(): String {
        return "demo-dagger.db"
    }

    @Provides
    @DatabaseInfo
    fun provideDatabaseVersion(): Int {
        return 2
    }

    @Provides
    fun provideSharedPrefs(): SharedPreferences {
        return mApplication.getSharedPreferences("demo-prefs", Context.MODE_PRIVATE)
    }
}