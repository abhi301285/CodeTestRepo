package com.example.dependencyinjectionpoc

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.example.dependencyinjectionpoc.data.DataManager
import com.example.dependencyinjectionpoc.data.model.User
import com.example.dependencyinjectionpoc.di.component.ActivityComponent
import com.example.dependencyinjectionpoc.di.component.DaggerActivityComponent
import com.example.dependencyinjectionpoc.di.module.ActivityModule
import kotlinx.android.synthetic.main.activity_main.*
import javax.inject.Inject


class MainActivity : AppCompatActivity() {

    @Inject
    lateinit var mDataManager: DataManager

    private var activityComponent: ActivityComponent? = null

    private fun getActivityComponent(): ActivityComponent? {
        if (activityComponent == null) {
            activityComponent = DaggerActivityComponent.builder()
                .activityModule(ActivityModule(this))
                .applicationComponent(DIApplication.get(this).component)
                .build()
        }
        return activityComponent
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        getActivityComponent()!!.inject(this)

    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        deleteAllUserData()
        createUser()
        // getUser()
        getAllUser()
        mDataManager.saveAccessToken("ASDR12443JFDJF43543J543H3K543")

        val token = mDataManager.accessToken
        if (token != null) {
            tv_access_token.text = token
        }
    }

    private fun createUser() {
        try {
            mDataManager.createUser(User("XYZ", "Hyderabad, India"))
            mDataManager.createUser(User("ABC", "NEW YORK, US"))
            mDataManager.createUser(User("qwerty", "LONDON, UK"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getUser() {
        try {
            val user = mDataManager.getUser(1L)
            tv_user_info.text = user.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getAllUser() {
        try {
            val user = mDataManager.getAllUser()
            val strBuilder = java.lang.StringBuilder()
            for (userData in user) {
                strBuilder.append(userData.toString())
            }
            tv_user_info.text = strBuilder.toString()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    private fun deleteAllUserData() {
        try {
            mDataManager.deleteAllUsers()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
