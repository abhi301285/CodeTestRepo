package com.example.dependencyinjectionpoc.di.module

import android.app.Activity
import android.content.Context
import com.example.dependencyinjectionpoc.di.ActivityContext
import dagger.Module
import dagger.Provides


/**
 * Created by Abhijit on 22/03/19.
 */

@Module
class ActivityModule(private val mActivity: Activity) {

    @Provides
    @ActivityContext
    fun provideContext(): Context {
        return mActivity
    }

    @Provides
    fun provideActivity(): Activity {
        return mActivity
    }
}
