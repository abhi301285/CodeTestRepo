package com.example.dependencyinjectionpoc.di.component

import com.example.dependencyinjectionpoc.MainActivity
import com.example.dependencyinjectionpoc.di.PerActivity
import com.example.dependencyinjectionpoc.di.module.ActivityModule
import dagger.Component

/**
 * Created by Abhijit on 22/03/19.
 */

@PerActivity
@Component(dependencies = [ApplicationComponent::class], modules = [ActivityModule::class])
interface ActivityComponent {

    fun inject(mainActivity: MainActivity)

}
