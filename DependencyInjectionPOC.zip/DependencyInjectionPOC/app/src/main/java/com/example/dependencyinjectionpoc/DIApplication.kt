package com.example.dependencyinjectionpoc

import android.app.Application
import android.content.Context
import com.example.dependencyinjectionpoc.data.DataManager
import com.example.dependencyinjectionpoc.di.component.ApplicationComponent
import com.example.dependencyinjectionpoc.di.component.DaggerApplicationComponent
import com.example.dependencyinjectionpoc.di.module.ApplicationModule
import javax.inject.Inject


class DIApplication : Application() {

    lateinit var component: ApplicationComponent

    @Inject
    lateinit var dataManager: DataManager

    override fun onCreate() {
        super.onCreate()
        component = DaggerApplicationComponent
            .builder()
            .applicationModule(ApplicationModule(this))
            .build()
        component.inject(this)
    }

    companion object {

        operator fun get(context: Context): DIApplication {
            return context.applicationContext as DIApplication
        }
    }
}

