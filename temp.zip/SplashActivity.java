package com.ui.splash;

import android.content.DialogInterface;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import javax.inject.Inject;



public class SplashActivity extends BaseActivity implements ISplashMvpView {
    @Inject SplashPresenter mPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityComponent().inject(this);
        setContentView(R.layout.activity_splash);
        mPresenter.attachView(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mPresenter.initializeAccessToken(this);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mPresenter.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPresenter.detachView();
    }

    @Override
    public void openContainerActivity() {
        if(mPresenter.isFirstTime()){
            startActivity(new Intent(getBaseContext(), TermsConditionActivity.class));
            finish();
        }else{
            startActivity(new Intent(getBaseContext(), MyDbsContainerActivity.class));
            finish();
        }

    }

    @Override
    public void showAuthenticationError() {
        DialogFactory.showDialog(this, "Error", getString(R.string.error_authentication), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        }), null);
    }

    @Override
    public void showConnectionError() {
        // User has already used the app before and has user details in prefs
        if(mPresenter.hasUserData()){
            openContainerActivity();
        }else{
            // User don't have user details -> Block them from entering the app.
            DialogFactory.showDialog(this, "Error", getString(R.string.error_unable_connect_server), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            }), null);
        }

    }


    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void showNetworkError() {
        DialogFactory.showDialog(this, "Network Error", getString(R.string.error_no_network), false,  new DialogFactory.DialogButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        }), null);
    }

    @Override
    public boolean checkTokenExpiry() {
        return false;
    }
}
