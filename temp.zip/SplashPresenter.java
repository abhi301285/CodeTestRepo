package com..ui.splash;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import android.os.Handler;
import android.text.TextUtils;
import android.widget.Toast;


import com.google.gson.Gson;
import com.microsoft.aad.adal.ADALError;
import com.microsoft.aad.adal.AuthenticationCallback;

import com.microsoft.aad.adal.AuthenticationException;
import com.microsoft.aad.adal.AuthenticationResult;
import javax.inject.Inject;

import rx.Observer;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import timber.log.Timber;


@ConfigPersistent
public class SplashPresenter extends BasePresenter<ISplashMvpView> {
    private final DataManager mDataManager;
    private Subscription mGetStartSubscription;
    private final Context mContext;
    private Activity mActivity;
    private TokenHelper mTokenHelper;


    @Inject
    SplashPresenter(DataManager dataManager, @ApplicationContext Context context) {
        mDataManager = dataManager;
        mContext = context;
        mTokenHelper = TokenHelper.getInstance(context);
    }

    @Override
    public void attachView(ISplashMvpView mvpView) {
        super.attachView(mvpView);
    }

    @Override
    public void detachView() {
        super.detachView();
        if (mGetStartSubscription != null) mGetStartSubscription.unsubscribe();

    }


    public void initializeAccessToken(final Activity activity) {
        if(!NetworkUtil.isNetworkConnected(mContext)){
            getMvpView().showNetworkError();
            return;
        }

        mActivity = activity;
        String azureADUserId = mDataManager.getPreferencesHelper().getADUserId();
        if (TextUtils.isEmpty(azureADUserId)) {
            mTokenHelper.callAcquireToken(activity, acquireTokenCallback);
        } else {
            mTokenHelper.callAcquireTokenSilentAsyc(azureADUserId, acquireTokenSilentCallback);
        }
    }

    private AuthenticationCallback<AuthenticationResult> acquireTokenCallback = new AuthenticationCallback<AuthenticationResult>() {
        @Override
        public void onSuccess(AuthenticationResult authResult) {

            if (authResult.getUserInfo() != null) {
                mDataManager.getPreferencesHelper().setOneBankId(Util.getOneBankId(authResult.getUserInfo().getDisplayableId()));
                mDataManager.getPreferencesHelper().setADUserId(authResult.getUserInfo().getUserId());
            }

            onTokenAcquired(authResult);
        }

        @Override
        public void onError(Exception exc) {
            failedToAcquireToken(exc);
        }
    };


    private AuthenticationCallback<AuthenticationResult> acquireTokenSilentCallback = new AuthenticationCallback<AuthenticationResult>() {
        @Override
        public void onSuccess(AuthenticationResult result) {
            onTokenAcquired(result);
        }

        @Override
        public void onError(Exception exc) {
            failedToAcquireToken(exc);
        }
    };


    private void onTokenAcquired(AuthenticationResult authenticationResult) {
        Timber.d("TOKEN: " + authenticationResult.getAccessToken());
        Timber.d("EXPIRY: " + authenticationResult.getExpiresOn().toString());

        mDataManager.getPreferencesHelper().setSessionId(authenticationResult.getAccessToken());
        mDataManager.getPreferencesHelper().setTokenExpiryDate(authenticationResult.getExpiresOn().getTime());

        callGetStart();
    }

    private void callGetStart(){
        boolean isDayElapsed = CalendarUtil.isDayElapsed(mDataManager.getPreferencesHelper().getLastGetStartUpdate());
        if (!hasUserData() || isDayElapsed) {
            getStartUser();
        } else {
            getMvpView().openContainerActivity();
        }
    }

    private void failedToAcquireToken(Exception ex) {
        Timber.e(ex.getMessage());

        if(ex instanceof AuthenticationException){
            AuthenticationException e = (AuthenticationException) ex;

            if(e.getCode() == ADALError.AUTH_REFRESH_FAILED_PROMPT_NOT_ALLOWED){
                mTokenHelper.callAcquireToken(mActivity, acquireTokenCallback);
            }
        }else{
            if (getMvpView() != null) getMvpView().showAuthenticationError();
        }

    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        mTokenHelper.onActivityResult(requestCode, resultCode, data);
    }

    private void showMessage(final String msg) {
        Timber.v(msg);
        getHandler().post(new Runnable() {

            @Override
            public void run() {
                Toast.makeText(mContext, msg, Toast.LENGTH_LONG).show();
            }
        });
    }


    private Handler getHandler() {
        return new Handler(mContext.getMainLooper());
    }

    public boolean isFirstTime() {
        return mDataManager.getPreferencesHelper().getIsFirstTime();
    }

    public boolean hasUserData() {
        boolean hasUserData = true;
        if (TextUtils.isEmpty(mDataManager.getPreferencesHelper().getUserId())) {
            hasUserData = false;
        } else if (TextUtils.isEmpty(mDataManager.getPreferencesHelper().getOneBankId())) {
            hasUserData = false;
        }

        return hasUserData;
    }

    private void getStartUser() {
        checkViewAttached();
        RxUtil.unsubscribe(mGetStartSubscription);
        mGetStartSubscription = mDataManager.getStartManager().getStartAndGetContactInfoObservable()
                .onBackpressureDrop()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<GetStartManager.GetStartAndGetContactInfo>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.e("getStartObserver >>> onError " + e.getMessage());
                        getMvpView().showConnectionError();
                    }

                    @Override
                    public void onNext(GetStartManager.GetStartAndGetContactInfo getStartAndGetContactInfo) {
                        GetStartUserResponse getStartUserResponse = getStartAndGetContactInfo.getGetStartUserResponse();
                        GetContactInfoResponse getContactInfoResponse = getStartAndGetContactInfo.getGetContactInfoResponse();

                        if (getStartUserResponse.getStatusCode().equals(Constants.WS_RESPONSE_STATUS_SUCCESS) &&
                                getContactInfoResponse.getStatusCode().equals(Constants.WS_RESPONSE_STATUS_SUCCESS)) {


                            mDataManager.getPreferencesHelper().setUserId(TextUtils.isEmpty(getStartUserResponse.getUserId())
                                    ? Constants.USER_DEFAULT_COUNTRY_CODE : getStartUserResponse.getUserId());
                            mDataManager.getPreferencesHelper().setAvatarImageUrl(getStartUserResponse.getAvatarImageUrl());
                            mDataManager.getPreferencesHelper().setUsername(getStartUserResponse.getDisplayName());
                            mDataManager.getPreferencesHelper().setEmployeeId(getStartUserResponse.getEmployeeId());

                            String countryCode = mDataManager.getPreferencesHelper().getCountryCode();
                            if (TextUtils.isEmpty(countryCode)) {
                                if (!TextUtils.isEmpty(getStartUserResponse.getCountryCode())) {
                                    mDataManager.getPreferencesHelper().setCountryCode(getStartUserResponse.getCountryCode());
                                } else {
                                    mDataManager.getPreferencesHelper().setCountryCode(CountrySelectionEnum.SINGAPORE.getCountryCode());
                                }
                            }

                            int moodCode = Integer.parseInt(getStartUserResponse.getMoodCode());
                            // IF MOOD CODE IS FROM OLD APP -> SET IT TO 0
                            String moodValue = moodCode > 4 ? Integer.toString(0) : getStartUserResponse.getMoodCode();

                            mDataManager.getPreferencesHelper().setMoodCode(moodValue);
                            mDataManager.getPreferencesHelper().setServerMoodCode(moodValue);
                            mDataManager.getPreferencesHelper().setAndroidLatestVersion(getStartUserResponse.getAndroidLatestVersion());
                            mDataManager.getPreferencesHelper().setLastGetstartUpdate(System.currentTimeMillis());


                            mDataManager.getPreferencesHelper().setContactInfoJson(new Gson().toJson(getContactInfoResponse));
                            getMvpView().openContainerActivity();
                        } else {
                            if (getMvpView() != null) getMvpView().showConnectionError();
                        }

                    }
                });
    }


}
